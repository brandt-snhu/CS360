package com.example.eventtrackertrevorbrandt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity
 * -------------
 * This activity handles user authentication and account creation.
 * It connects the login interface (activity_login.xml) to the SQLite database
 * through the DatabaseHelper class.
 *
 * Key responsibilities:
 *  - Validate user credentials for login
 *  - Allow new users to create an account
 *  - Navigate to HomeActivity after successful authentication
 */
public class LoginActivity extends AppCompatActivity {

    // Input fields for username and password
    private EditText usernameInput, passwordInput;

    // Buttons for login and account creation
    private Button loginButton, createAccountButton;

    // Database helper instance for user management
    private DatabaseHelper dbHelper;

    /**
     * onCreate:
     * Called when the activity is first created.
     * Initializes the layout, sets up input validation, and defines button behaviors.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Link Java variables to XML layout components
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize database helper to manage user credentials
        dbHelper = new DatabaseHelper(this);

        // --------------------------------------------------
        // LOGIN BUTTON LOGIC
        // --------------------------------------------------
        loginButton.setOnClickListener(v -> {
            // Get user input and trim extra spaces
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate that both fields are filled
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check database for valid user credentials
            if (dbHelper.checkUser(username, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Move to the Home screen after successful login
                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                finish(); // Close login activity to prevent back navigation
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // --------------------------------------------------
        // CREATE ACCOUNT BUTTON LOGIC
        // --------------------------------------------------
        createAccountButton.setOnClickListener(v -> {
            // Get user input and trim extra spaces
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate that both fields are filled
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if username already exists in the database
            if (dbHelper.userExists(username)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else {
                // Insert new account record into the database
                boolean inserted = dbHelper.insertUser(username, password);
                if (inserted) {
                    Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

                    // Navigate to HomeActivity after successful account creation
                    startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
