package com.example.eventtrackertrevorbrandt;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * EventAdapter
 * -------------
 * This adapter bridges the list of Event objects and the RecyclerView in HomeActivity.
 * It manages how each event item is displayed in the grid and handles delete actions.
 *
 * Key responsibilities:
 *  - Inflate the event item layout for each row
 *  - Bind event data (name, date, time) to the views
 *  - Handle user interaction such as deleting an event
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {

    // List of all event objects currently displayed in the RecyclerView
    private List<Event> eventList;

    // Reference to the database helper for performing delete operations
    private DatabaseHelper dbHelper;

    /**
     * Constructor:
     * Receives a list of Event objects and a DatabaseHelper instance.
     * The data in eventList is displayed dynamically through the adapter.
     */
    public EventAdapter(List<Event> eventList, DatabaseHelper dbHelper) {
        this.eventList = eventList;
        this.dbHelper = dbHelper;
    }

    /**
     * onCreateViewHolder:
     * Called when the RecyclerView needs a new ViewHolder.
     * Inflates the layout for an individual event item from item_event.xml.
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the event item layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new ViewHolder(view);
    }

    /**
     * onBindViewHolder:
     * Binds event data (name, date, time) to the corresponding views in each list item.
     * Also defines the delete button’s behavior.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the current event from the list
        Event event = eventList.get(position);

        // Bind event data to TextViews
        holder.eventName.setText(event.getName());
        holder.eventDate.setText(event.getDate());
        holder.eventTime.setText(event.getTime());

        /**
         * Delete Button Listener:
         * When the user taps "Delete," this removes the event from the database
         * and updates the RecyclerView to reflect the change immediately.
         */
        holder.deleteButton.setOnClickListener(v -> {
            // Delete from database
            dbHelper.deleteEvent(event.getId());

            // Remove from in-memory list and update RecyclerView
            eventList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, eventList.size());
        });
    }

    /**
     * getItemCount:
     * Returns the total number of events currently stored in the list.
     * Used by RecyclerView to determine how many items to render.
     */
    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * ViewHolder
     * ----------
     * Represents a single event item view in the RecyclerView.
     * Holds references to the TextViews and Delete Button for quick access.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        // UI components inside the event item layout
        TextView eventName, eventDate, eventTime;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.eventName);
            eventDate = itemView.findViewById(R.id.eventDate);
            eventTime = itemView.findViewById(R.id.eventTime);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
