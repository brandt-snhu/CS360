package com.example.eventtrackertrevorbrandt;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

/**
 * HomeActivity
 * -------------
 * This activity serves as the main screen after login.
 * It displays all saved events in a two-column grid and allows users
 * to add new events or manage SMS notification settings.
 *
 * Key responsibilities:
 *  - Load events from the SQLite database
 *  - Display them in a RecyclerView grid using EventAdapter
 *  - Provide navigation to AddEventActivity and SmsActivity
 */
public class HomeActivity extends AppCompatActivity {

    // RecyclerView to display event data in a grid
    private RecyclerView eventRecyclerView;

    // Adapter for binding event data to the RecyclerView
    private EventAdapter eventAdapter;

    // SQLite database helper to manage CRUD operations
    private DatabaseHelper dbHelper;

    /**
     * onCreate:
     * Initializes the layout and UI elements when the activity starts.
     * Sets up navigation buttons and the grid layout manager.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Set up RecyclerView and display items in a 2-column grid
        eventRecyclerView = findViewById(R.id.eventRecyclerView);
        eventRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Floating Action Button → Opens AddEventActivity to create a new event
        FloatingActionButton addEventFab = findViewById(R.id.addEventFab);
        addEventFab.setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, AddEventActivity.class)));

        // SMS Settings Button → Opens SmsActivity for permission control
        findViewById(R.id.smsButton).setOnClickListener(v ->
                startActivity(new Intent(HomeActivity.this, SmsActivity.class)));
    }

    /**
     * onResume:
     * Called whenever the activity becomes visible again (e.g., returning from AddEventActivity).
     * This ensures that the event list is refreshed with any new or deleted events.
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }

    /**
     * loadEvents:
     * Retrieves all events from the database and binds them to the RecyclerView using EventAdapter.
     * This method is called from onResume() to always reflect the latest data.
     */
    private void loadEvents() {
        // Fetch all stored events
        List<Event> eventList = dbHelper.getAllEvents();

        // Create and assign a new adapter each time the list changes
        eventAdapter = new EventAdapter(eventList, dbHelper);
        eventRecyclerView.setAdapter(eventAdapter);
    }
}
