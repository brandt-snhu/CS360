package com.example.eventtrackertrevorbrandt;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper
 * ----------------
 * Handles all database operations for the Event Tracker app.
 * Includes two main tables:
 *   1. USERS  - Stores login credentials (username, password)
 *   2. EVENTS - Stores event details (name, date, time)
 *
 * Provides CRUD (Create, Read, Update, Delete) operations for both tables.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // --- Database configuration ---
    private static final String DATABASE_NAME = "event_tracker.db";
    private static final int DATABASE_VERSION = 2; // Increment version when modifying schema

    // --- Users table definition ---
    private static final String TABLE_USERS = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // --- Events table definition ---
    private static final String TABLE_EVENTS = "events";
    private static final String COL_ID = "id";
    private static final String COL_EVENT_NAME = "event_name";
    private static final String COL_EVENT_DATE = "event_date";
    private static final String COL_EVENT_TIME = "event_time";

    /**
     * Constructor:
     * Initializes the SQLiteOpenHelper with database name and version.
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * onCreate:
     * Called when the database is first created.
     * Defines both the USERS and EVENTS tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create USERS table for login credentials
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        // Create EVENTS table for storing event data
        String createEvents = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_EVENT_NAME + " TEXT, " +
                COL_EVENT_DATE + " TEXT, " +
                COL_EVENT_TIME + " TEXT)";
        db.execSQL(createEvents);
    }

    /**
     * onUpgrade:
     * Called when the database version number increases.
     * Drops existing tables and recreates them to apply schema updates.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // =====================================================================
    // USERS TABLE OPERATIONS
    // =====================================================================

    /**
     * insertUser:
     * Adds a new user record to the USERS table.
     * Returns true if successful, false otherwise.
     */
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1; // Return true if insertion succeeded
    }

    /**
     * checkUser:
     * Verifies if a username/password combination exists in the USERS table.
     * Used for login validation.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password});
        boolean exists = cursor.moveToFirst(); // Returns true if a match is found
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * userExists:
     * Checks if a username already exists in the USERS table.
     * Used to prevent duplicate account creation.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=?",
                new String[]{username});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();
        return exists;
    }

    // =====================================================================
    // EVENTS TABLE OPERATIONS
    // =====================================================================

    /**
     * insertEvent:
     * Adds a new event record to the EVENTS table.
     * Each record includes a name, date, and time.
     */
    public boolean insertEvent(String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return result != -1;
    }

    /**
     * getAllEvents:
     * Retrieves all events from the EVENTS table and returns them as a list.
     * Each result is mapped to an Event object for easy use in RecyclerView.
     */
    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);

        if (cursor.moveToFirst()) {
            do {
                // Extract data from each row in the cursor
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_EVENT_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_EVENT_DATE));
                String time = cursor.getString(cursor.getColumnIndexOrThrow(COL_EVENT_TIME));

                // Add new Event object to the list
                events.add(new Event(id, name, date, time));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return events;
    }

    /**
     * deleteEvent:
     * Deletes an event record from the EVENTS table based on its ID.
     * Called when the user taps the Delete button in the RecyclerView grid.
     */
    public void deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    /**
     * updateEvent:
     * Updates an existing event’s name, date, and time based on its ID.
     * Useful for future app versions that may include event editing.
     */
    public void updateEvent(int id, String name, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_EVENT_NAME, name);
        values.put(COL_EVENT_DATE, date);
        values.put(COL_EVENT_TIME, time);
        db.update(TABLE_EVENTS, values, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
}