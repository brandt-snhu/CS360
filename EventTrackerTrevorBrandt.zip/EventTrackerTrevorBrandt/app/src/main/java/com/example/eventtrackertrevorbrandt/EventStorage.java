package com.example.eventtrackertrevorbrandt;

import java.util.ArrayList;
import java.util.List;

/**
 * EventStorage
 * -------------
 * This utility class provides a simple in-memory storage for Event objects.
 * It maintains a static list that temporarily holds events during the app’s runtime.
 *
 * Although the primary data is stored in the SQLite database, this class
 * can be used for quick access, caching, or testing when database persistence
 * is not required (for example, before implementing full CRUD logic).
 */
public class EventStorage {

    // Static list that temporarily stores all events in memory
    private static final List<Event> events = new ArrayList<>();

    /**
     * addEvent:
     * Adds a new Event object to the in-memory list.
     * This method is useful when adding items that are not yet saved in the database.
     *
     * @param event the Event object to add
     */
    public static void addEvent(Event event) {
        events.add(event);
    }

    /**
     * getEvents:
     * Returns a copy of the current list of events.
     * A new ArrayList is returned to prevent external modification
     * of the internal events list.
     *
     * @return a new list containing all current events
     */
    public static List<Event> getEvents() {
        return new ArrayList<>(events);
    }

    /**
     * removeEvent:
     * Removes a specific Event object from the in-memory list.
     * This can be used to reflect deletions before or after database updates.
     *
     * @param event the Event object to remove
     */
    public static void removeEvent(Event event) {
        events.remove(event);
    }
}
