package com.example.eventtrackertrevorbrandt;

import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * AddEventActivity
 * ----------------
 * This activity allows the user to create and save a new event.
 * The user inputs an event name, date, and time, which are then stored
 * in the SQLite database through the DatabaseHelper class.
 */
public class AddEventActivity extends AppCompatActivity {

    // Reference to the SQLite database helper class
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialize the database helper instance
        dbHelper = new DatabaseHelper(this);

        // Link UI elements from XML layout to Java variables
        EditText nameInput = findViewById(R.id.eventNameInput);
        DatePicker datePicker = findViewById(R.id.datePicker);
        TimePicker timePicker = findViewById(R.id.timePicker);
        Button saveButton = findViewById(R.id.saveEventButton);

        /**
          * Save Button Listener:
          * When the user taps "Save Event", this code retrieves the entered data,
          * validates that the name is not empty, and inserts a new event record
          * into the SQLite database using dbHelper.insertEvent().
          */
        saveButton.setOnClickListener(v -> {
            // Get the event name text
            String name = nameInput.getText().toString().trim();

            // Format the date and time into readable strings
            String date = (datePicker.getMonth() + 1) + "/" + datePicker.getDayOfMonth();
            String time = timePicker.getHour() + ":" + String.format("%02d", timePicker.getMinute());

            // Ensure that the event name field is not left empty
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter an event name", Toast.LENGTH_SHORT).show();
                return;
            }

            // Insert the event data into the database
            boolean inserted = dbHelper.insertEvent(name, date, time);

            // Provide feedback to the user based on the insert result
            if (inserted) {
                Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();
                finish();  // Close the Add Event screen and return to HomeActivity
            } else {
                Toast.makeText(this, "Error saving event", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
