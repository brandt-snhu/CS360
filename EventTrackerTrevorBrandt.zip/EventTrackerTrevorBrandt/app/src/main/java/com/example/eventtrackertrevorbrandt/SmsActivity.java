package com.example.eventtrackertrevorbrandt;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * SmsActivity
 * ------------
 * This activity manages user permissions for sending SMS messages.
 * It requests, checks, and displays the status of the SEND_SMS permission.
 *
 * Key responsibilities:
 *  - Prompt the user to allow or deny SMS access
 *  - Display the current permission status
 *  - Handle user responses and update the UI accordingly
 *
 * The rest of the app (e.g., notifications) depends on this setting
 * but still functions normally even if permission is denied.
 */
public class SmsActivity extends AppCompatActivity {

    // Request code identifier for SMS permission result callback
    private static final int SMS_PERMISSION_REQUEST = 101;

    // UI elements for displaying and requesting SMS permission
    private TextView permissionStatus;
    private Button requestPermissionButton;

    /**
     * onCreate:
     * Called when the activity starts.
     * Initializes layout components and checks the current SMS permission status.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Link UI elements from XML layout
        permissionStatus = findViewById(R.id.permissionStatus);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);

        // Display the current permission state to the user
        checkSmsPermission();

        // When tapped, request SMS permission from the system
        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());
    }

    /**
     * checkSmsPermission:
     * Checks whether the SEND_SMS permission is already granted.
     * Updates the TextView message accordingly.
     */
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            // User has already granted permission
            permissionStatus.setText("Permission granted: SMS notifications are enabled.");
        } else {
            // Permission not granted yet
            permissionStatus.setText("Permission not granted: Tap above to allow SMS access.");
        }
    }

    /**
     * requestSmsPermission:
     * Launches the Android system dialog to request SMS sending permissions.
     * The user’s response is handled in onRequestPermissionsResult().
     */
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST
        );
    }

    /**
     * onRequestPermissionsResult:
     * Called automatically after the user grants or denies SMS permission.
     * Updates UI text and provides feedback with Toast messages.
     *
     * @param requestCode   The code used when requesting permission
     * @param permissions   The list of requested permissions
     * @param grantResults  The result array indicating if permissions were granted
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Ensure the callback matches our SMS request
        if (requestCode == SMS_PERMISSION_REQUEST) {
            // Permission granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatus.setText("Permission granted: SMS notifications are enabled.");
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();

                // Permission denied
            } else {
                permissionStatus.setText("Permission denied: SMS notifications disabled.");
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
