package com.example.eventtrackertrevorbrandt;

/**
 * Event
 * -----
 * This is a simple model (data) class that represents a single event record.
 * It stores the event’s ID (from the database), name, date, and time.
 *
 * Each Event object corresponds to one row in the "events" table of the SQLite database.
 * These objects are used by the RecyclerView adapter to populate the event grid on the Home screen.
 */
public class Event {

    // Unique identifier for the event (primary key in the database)
    private int id;

    // Event details: name, date, and time
    private String name;
    private String date;
    private String time;

    /**
     * Constructor used when retrieving an event that already exists in the database.
     * Includes the ID field assigned by SQLite.
     */
    public Event(int id, String name, String date, String time) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
    }

    /**
     * Constructor used when creating a new event before it is saved in the database.
     * The ID is not included here because it is automatically generated when inserted.
     */
    public Event(String name, String date, String time) {
        this.name = name;
        this.date = date;
        this.time = time;
    }

    // -----------------------------
    // Getter methods for each field
    // -----------------------------

    /** Returns the unique ID of the event. */
    public int getId() { return id; }

    /** Returns the event name. */
    public String getName() { return name; }

    /** Returns the event date (formatted as MM/DD). */
    public String getDate() { return date; }

    /** Returns the event time (formatted as HH:MM). */
    public String getTime() { return time; }
}
